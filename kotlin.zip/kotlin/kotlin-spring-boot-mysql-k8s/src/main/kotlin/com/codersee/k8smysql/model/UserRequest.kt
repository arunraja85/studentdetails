package com.codersee.k8smysql.model

class UserRequest(
    val name: String
)
