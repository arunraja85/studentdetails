rootProject.name = "k8s-mysql"
